public class ItemTest {
    public static void main(String[] args) {
        class Item {
            public String name;
            public int price; 
        }
        

    }

        
}
