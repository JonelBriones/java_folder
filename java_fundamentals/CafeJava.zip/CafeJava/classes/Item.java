package classes;
public class Item {
    public String name;
    public double price; 
    
    public Item(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public void addItem(String name, double price) {
        System.out.print(name + " $" + price);
    }
}
